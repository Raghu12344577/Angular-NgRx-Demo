import { Component, OnInit } from '@angular/core';
import { Store } from '@ngrx/store';
import { Observable, of } from 'rxjs';
import { AddShoppingItemAction, DeleteShoppingItemAction, LoadShoppingItemAction, UpdateShoppingItemAction } from './store/actions/shopping.action';
import { ShoppingState } from './store/model/shopping-state.model';
import { shoppingItem } from './store/model/shopping-item.model';
import { getStateShopping } from './store/selectors/shopping.selectors';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  title = 'angular-bootstrap';
  
  shoppingItems:Observable<Array<shoppingItem>>;

  initialState:Array<shoppingItem> = [
    {
        id : "1",
        name : "Diet Coke",
        status : "ToDo"
    },
    {
        id : "3",
        name : "Apple Shake",
        status : "ToDo"
    },
    {
        id : "4",
        name : "Mango Shake",
        status : "Inprogress"
    },
    {
        id : "5",
        name : "Bingo",
        status : "ToDo"
    },
    {
        id : "6",
        name : "Chaco's",
        status : "completed"
    }
]

  constructor(private store : Store<ShoppingState>){}

  ngOnInit(){
    this.store.dispatch(new LoadShoppingItemAction(this.initialState));
    this.store.select(getStateShopping).subscribe((data:any) =>{
      console.log("add state data using selectors",data);
      this.shoppingItems = of(data);
    })
  }

  addItem(){
    this.store.dispatch(new AddShoppingItemAction({id:'2',name:'Fanta',status:'ToDo'}));
  }

  deleteItem(){
    this.store.dispatch(new DeleteShoppingItemAction('4'));
  }

  updateItem(clickedItem){
    if(clickedItem.name == 'Apple Shake'){
      clickedItem.name = 'Fig Shake',
      clickedItem.status = 'completed'
    }
    else{
      clickedItem.status = 'completed'
    }
    this.store.dispatch(new UpdateShoppingItemAction(clickedItem));
  }
}
