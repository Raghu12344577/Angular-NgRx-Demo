import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveFormComponent } from '../reactive-form/reactive-form.component';
import { TemplateDrivenFormComponent } from '../template-driven-form/template-driven-form.component';
import {Routes,RouterModule} from '@angular/router';

const routes : Routes = [
  {path : 'TemplateDriven',component : TemplateDrivenFormComponent},
  {path : 'Reactive',component : ReactiveFormComponent}
];

@NgModule({
  declarations: [
    ReactiveFormComponent,
    TemplateDrivenFormComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    FormsModule,
    RouterModule.forChild(routes)
  ]
})
export class LazyLoadModule { }
