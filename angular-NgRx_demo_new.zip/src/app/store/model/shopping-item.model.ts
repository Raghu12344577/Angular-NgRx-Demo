export interface shoppingItem{
    id:string,
    name:string,
    status:string
}