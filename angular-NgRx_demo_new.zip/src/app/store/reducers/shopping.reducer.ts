import { ShoppingAction, ShoppingActionType } from "../actions/shopping.action";
import { shoppingItem} from "../model/shopping-item.model";

export function shoppingReducer(state :Array<shoppingItem>,action :ShoppingAction){
    console.log("state,action",state,action);
    if(typeof state == 'undefined'){
        return action.payload;
    }
    switch(action.type){
        case ShoppingActionType.LOAD_ITEM:
            return [...state,];
        case ShoppingActionType.ADD_ITEM:
            const found = state.some(item => item.id == action.payload.id);
            if(!found){
                return [...state,action.payload];
            }
        case ShoppingActionType.DELETE_ITEM:
            return state.filter(item => item.id != action.payload);
        case ShoppingActionType.UPDATE_ITEM:
            state.forEach(ele =>{
                if(ele.id == action.payload.id){
                    ele.name = action.payload.name;
                }
            })
            console.log("state,action after update",state,action);
            return [...state];
        default:
            return state;
    }
}