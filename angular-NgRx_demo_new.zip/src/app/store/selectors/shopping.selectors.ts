import { createFeatureSelector, createSelector } from "@ngrx/store";
import { shoppingItem } from "../model/shopping-item.model";

const getShoppingList = createFeatureSelector<shoppingItem>('shopping');

export const getStateShopping = createSelector(getShoppingList,state =>{
    return state;
})