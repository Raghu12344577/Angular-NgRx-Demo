import { Injectable } from '@angular/core';
import { Actions, Effect } from '@ngrx/effects';
import { ofType } from '@ngrx/effects';
import { switchMap, map } from 'rxjs/operators';
import { JsondataService } from 'src/app/service/jsondata.service';
import { LoadShoppingItemAction, ShoppingActionType } from '../actions/shopping.action';

@Injectable()
export class ShoppingEffects {
  constructor(private actions: Actions,private jsonService : JsondataService) {}

  @Effect()

  loadJsonData = this.actions.pipe(
      ofType(ShoppingActionType.LOAD_ITEM),
      switchMap(() =>
        this.jsonService.getShoppingJsonData().pipe(
            map(data => new LoadShoppingItemAction(data))
        )
      )
  )
  
}