import { Action } from "@ngrx/store";
import { shoppingItem } from "../model/shopping-item.model";

export enum ShoppingActionType{
    LOAD_ITEM = '[SHOPPING] Load Item',
    ADD_ITEM = '[SHOPPING] Add Item',
    DELETE_ITEM = '[SHOPPING] Delete Item',
    UPDATE_ITEM = '[SHOPPING] update Item'
}

export class LoadShoppingItemAction implements Action{
    readonly type = ShoppingActionType.LOAD_ITEM;

    constructor(public payload:any){}
}

export class AddShoppingItemAction implements Action{
    readonly type = ShoppingActionType.ADD_ITEM;

    constructor(public payload:shoppingItem){}
}

export class DeleteShoppingItemAction implements Action{
    readonly type = ShoppingActionType.DELETE_ITEM;

    constructor(public payload:string){}
}


export class UpdateShoppingItemAction implements Action{
    type = ShoppingActionType.UPDATE_ITEM;

    constructor(public payload:shoppingItem){}
}

export type ShoppingAction = LoadShoppingItemAction | AddShoppingItemAction | DeleteShoppingItemAction | UpdateShoppingItemAction;