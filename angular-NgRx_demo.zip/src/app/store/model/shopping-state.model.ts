import { shoppingItem } from "./shopping-item.model";

export interface ShoppingState{
    readonly shopping : Array<shoppingItem>
}