import { Directive,ElementRef,HostListener } from '@angular/core';

@Directive({
  selector: '[appHighlight]'
})
export class HighlightDirective {

  @HostListener('mouseenter') onMouseEnter(){
    this.highLightColor('red');
    this.hightLightFont('25px');
  }

  @HostListener('mouseleave') onMouseLeave(){
    this.highLightColor('');
    this.hightLightFont('20px');
  }

  constructor(private eletRef : ElementRef) { }

  highLightColor(color){
    this.eletRef.nativeElement.style.backgroundColor = color;
  }

  hightLightFont(size){
    this.eletRef.nativeElement.style.fontSize = size;
  }

}
