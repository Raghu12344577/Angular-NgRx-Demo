import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-template-driven-form',
  templateUrl: './template-driven-form.component.html',
  styleUrls: ['./template-driven-form.component.css']
})
export class TemplateDrivenFormComponent implements OnInit {
  @ViewChild('loginForm',{static : true}) public loginForm: NgForm;
  constructor() { }

  isSubmittedFlag:boolean = false;

  ngOnInit() {
    this.onChanges();
  }

  onChanges(){
    console.log("onchanges template driven",this.loginForm.form);
  }

  onSubmit(loginForm){
    console.log("submit template driven",loginForm.value)
  }

}
