import { Component, OnInit } from '@angular/core';
import {FormGroup,FormControl,FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-reactive-form',
  templateUrl: './reactive-form.component.html',
  styleUrls: ['./reactive-form.component.css']
})
export class ReactiveFormComponent implements OnInit {

  constructor(private fb : FormBuilder) { }

  loginFormGroup = this.fb.group({
    username : [''],
    password : ['']
  });

  userName:any = '';
  password:any = '';

  isSubmittedFlag:boolean = false;

  ngOnInit() {
    this.OnChanges();
  }

  OnChanges(){
    this.loginFormGroup.get('username').valueChanges.subscribe(user => {
      this.userName = user;
      if(this.userName != '' && this.password != ''){
        this.isSubmittedFlag = true;
      }
      else{
        this.isSubmittedFlag = false;
      }
      this.loginFormGroup.get('password').valueChanges.subscribe(password => {
        this.password = password;
        if(this.userName != '' && this.password != ''){
          this.isSubmittedFlag = true;
        }
        else{
          this.isSubmittedFlag = false;
        }
      });
    });
  }

  onSubmit(){
    console.log("submit",this.loginFormGroup.value);
    if(!this.loginFormGroup.valid){
      this.isSubmittedFlag = false;
    }
  }

}
