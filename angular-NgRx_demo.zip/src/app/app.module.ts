import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgModule } from '@angular/core';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './components/header/header.component';
import { ContentComponent } from './components/content/content.component';
import { FooterComponent } from './components/footer/footer.component';
import { HighlightDirective } from './directives/highlight.directive';
import { WordcountPipe } from './pipe/wordcount.pipe';
import {HttpClientModule,HttpClientXsrfModule} from '@angular/common/http';
import {HTTP_INTERCEPTORS} from '@angular/common/http';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';
import {shoppingReducer} from './store/reducers/shopping.reducer';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { environment } from 'src/environments/environment';
import { ShoppingEffects } from './store/effects/shopping.effects';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    ContentComponent,
    FooterComponent,
    HighlightDirective,
    WordcountPipe
  ],
  imports: [
    BrowserModule,
    ReactiveFormsModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    HttpClientXsrfModule.withOptions({
      cookieName:'XSRF-TOKEN',
      headerName:'X-XSRF-TOKEN'
    }), 
    StoreModule.forRoot({ shopping : shoppingReducer }),
    EffectsModule.forRoot([]),
    StoreDevtoolsModule.instrument({maxAge:25,logOnly:environment.production})
  ],
  providers: [
    {provide:HTTP_INTERCEPTORS,useExisting:HttpClientXsrfModule,multi:true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
