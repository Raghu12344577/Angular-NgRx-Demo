import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { shoppingItem } from '../store/model/shopping-item.model';

@Injectable({
  providedIn: 'root'
})
export class JsondataService {

  constructor(private http : HttpClient) { }

  getShoppingJsonData(){
    return this.http.get<shoppingItem>("../assets/jsonData/shoppingList.json");
  }
}
